plot.checks<-function(checks) {
  matplot(checks@tab,xlab="Increasing Sum Scores",ylab="% Violations",type="l",lty=1,col="black")
}

