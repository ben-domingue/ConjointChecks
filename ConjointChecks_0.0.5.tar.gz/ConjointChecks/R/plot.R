plot.checks<-function(x, ...) {
  matplot(x@tab,xlab="Increasing Sum Scores",ylab="% Violations",type="l",lty=1,col="black")
}

