PlotChecks<-function(mat) {
  matplot(mat$tab,xlab="Increasing Sum Scores",ylab="% Violations",type="l",lty=1,col="black")
}

